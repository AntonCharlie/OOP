class Kontak:

	def __init__(self, first, last, phone, address):
		self.first = first
		self.last = last
		self.phone = phone
		self.address = address