
class Pengguna:


	def __init__(self, username, first, last, password):
		self.username = username
		self.first = first
		self.last = last
		self.password = password


